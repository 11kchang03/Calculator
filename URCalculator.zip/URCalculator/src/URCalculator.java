import java.util.Arrays;

import javax.lang.model.element.UnknownAnnotationValueException;
import javax.lang.model.element.UnknownElementException;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.Math;
import java.lang.reflect.Array;

public class URCalculator {
	static String[] operators = {"+", "-", "*", "/", "(", ")", ">", "<", "=", "|", "&", "^", "%", "sin", "cos", "tan", "!"};
	static boolean exception = false;
	
	public static boolean isOperator(String op) {
		for (String o: operators) 
			if (op.equals(o)) 
				return true; // if any of the operators match op, return true
		return false; // if successfully ran through the entire operators array, cannot be an operator
	}
	
	public static boolean isOperand(String op) {
		return op.matches("\\d+(\\.\\d+)?"); // https://stackoverflow.com/questions/1102891/how-to-check-if-a-string-is-numeric-in-java
	}
	
	public static URLinkedList<String> readFile(String[] args){ // https://stackoverflow.com/questions/16802147/java-i-want-to-read-a-file-name-from-command-line-then-use-a-bufferedreader-to
        URLinkedList<String> expr = new URLinkedList<String>();
        File inFile = null;
        if (0 < args.length)
            inFile = new File(args[0]);
        else {
            System.err.println("Invalid arguments count:" + args.length);
            System.exit(0);
        }
        BufferedReader br = null;
        try {
            String sCurrentLine;
            br = new BufferedReader(new FileReader(inFile));
            expr.add("");
            while ((sCurrentLine = br.readLine()) != null)
                expr.add(sCurrentLine);
        } 
        catch (IOException e) {
            e.printStackTrace();
        } 
        finally {
            try {
                if (br != null) 
                	br.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return expr;
    }
	
	public static String check(String[] split) {
		// method to return the specific input that caused exception in checkException
		for (String i : split)
			if (!isOperand(i) && !isOperator(i))
				return i;
		return null;
	}
	
	public static void checkException(String[] split) throws Exception {
		// throws exception when unknown input found in expression
		for (String i : split)
			if (!isOperand(i) && !isOperator(i)) 
				throw new Exception();
	}
	
	public static String[] addSpaces(String line) throws Exception {
		String str = new String();
		String[] split = line.split("\\s+"); // split line into split string array by \\s+, 
												   // effectively removing all single or consecutive white spaces in curLine
		for (String i : split) {
			for (String j : operators)
				i = i.replace(j, " " + j + " "); // add spaces around every operator in i
			str = str + i; // before adding i to str variable
		}
		if (str.startsWith(" "))	// URCalculator would encounter an error whenever the expression had a right associative operator at the beginning
			str = str.substring(1); // because then the above code would input a space before that operator, making str begin with one empty space
									// To counter this, I simply deleted the beginning of str if it began with an empty space
		split = str.split("\\s+"); // split str by \\s+ to account for any double spaces

		try {
			checkException(split); // check addSpaces(line) for any n inputs
		} 
		catch (Exception e) { 
		// this is the first encounter of the unknown input exception
			System.out.println("--> Error: Unknown input: " + check(split));
			exception = true; // set exception true to let system know there's a typo in the input
		}														   
		
		
		return split; 
	}
	
	public static String[] unarySwitch(String[] split) {
		// switches every unary negative sign to n, to easily differentiate between negative and minus
		int index = 0;
		String prev = "+"; // set default of prev to arbitrary operator to account for the case where 
						   // the negative is at the beginning of split, in which case, prev would otherwise be null
		for (String i: split) {
			if (i.equals("-") && isOperator(prev) && !prev.equals(")"))
				split[index] = "`";
			prev = i; // set i as prev before traversing
			index++; // increment index variable
		}
		return split;
	}
	
	public static int prec(String op) throws Exception { // switch to assign precedence values to all operators
		int prec = 0;
		switch (op) {
		case "sin":
		case "cos":
		case "tan":
		case "!":
		case "`": // unary negative
			prec++;
		case "^":
			prec++;
		case "*":
		case "/":
		case "%":
			prec++;
		case "+":
		case "-":
			prec++;
		case "<":
		case ">":
			prec++;
		case "=":
			prec++;
		case "&":
			prec++;
		case "|":
		default: 
			return prec;
		}
	}
	
	public static boolean isLtoR(String op) throws Exception {
		switch (op) {
		case "!":
		case "sin":
		case "cos":
		case "tan":
		case "`":
			return false; // right to left associativity
		case "^":
		case "*":
		case "/":
		case "%":
		case "+":
		case "-":
		case "<":
		case ">":
		case "=":
		case "&":
		case "|":
		default:
			return true; // left to right associativity
		}
	}
	
	public static int numOperands(String op) throws Exception {
		switch (op) {
		case "&":
		case "|":
		case "=":
		case "<":
		case ">":
		case "+":
		case "-":
		case "*":
		case "/":
		case "%":
		case "^":
			return 2;
		case "!":
		case "sin":
		case "cos":
		case "tan":
		case "`":
		default: 
			return 1;
		}
	}
	
	public static double operate(String op, double x, double y) throws Exception {
		switch(op) {
		case "sin":
			return Math.sin(x);
		case "cos":
			return Math.cos(x);
		case "tan":
			return Math.tan(x);
		case "&":
			if (x == 1 && y == 1)
				return 1;
			else if (!((x == 0 || x == 1) && (y == 0 || y == 1)))
				// if neither x or y are of value 0 or 1, throw exception
				throw new Exception();
			else
				return 0;
		case "|":
			if (x == 1 || y == 1)
				return 1;
			else if (!((x == 0 || x == 1) && (y == 0 || y == 1)))
				// if neither x or y are of value 0 or 1, throw exception
				throw new Exception();
			else
				return 0;
		case "=":
			if (x == y)
				return 1;
			else
				return 0;
		case "<":
			if (x < y)
				return 1;
			else
				return 0;
		case ">":
			if (x > y)
				return 1;
			else
				return 0;
		case "+":
			return x + y;
		case "-":
			return x - y;
		case "*":
			return x * y;
		case "/":
			return x / y;
		case "%":
			return x % y;
		case "^":
			return Math.pow(x, y);
		case "!":
			if (x == 0)
				return 1;
			else if (x == 1)
				return  0;
			else
				// if x is not 0 or 1, throw exception
				throw new Exception();
		case "`":
			return -x;
		default: 
			// if op is not any of the listed operators, throw exception
			throw new Exception();
		}
	}

	public static Queue<String> in2post(String line) throws Exception {
		String[] curLine = addSpaces(line); // addSpaces to line
		curLine = unarySwitch(curLine); // update curLine with unarySwitch method
		
		Stack<String> s = new Stack<>();
		Queue<String> q = new Queue<>();
		for (String i : curLine) {
			if (isOperand(i)) 
				// if i is an operand
				q.enqueue(i);
			else if (i.equals(")")) { 
				// if i is closed parenthesis
				try { // in case where ")" was put in an inappropriate spot, catch exception
					while(!s.peek().equals("(")) {
						q.enqueue(s.peek()); // until the top of the stack is an open parenthesis,
						s.pop(); 			 // enqueue and pop the top of the stack
					}
					s.pop(); // then, pop the open parenthesis from the stack
				}
				catch (NullPointerException e) {
					System.out.println("--> Error: Closed parentheses inputted at invalid spot");
					exception = true;
				}
			} else if (i.equals("("))
				// if i is open parenthesis
				s.push(i);
			else if (s.isEmpty()) {
				// if the stack is empty
				s.push(i);
			} else {
				// if i is not a parenthesis
				try {
					while (!(s.peek().equals("(") 											// NOT [peek = open parenthesis
						|| (!isLtoR(s.peek()) && !isLtoR(i) && prec(s.peek()) == prec(i)) 	// 	    OR peek and i are right to left associative operators of equal precedence				
						|| prec(i) > prec(s.peek().toString())      						// 		OR precedence(i) > precedence(peek)
						|| s.isEmpty())) {  												// 		OR s is empty]
					
						q.enqueue(s.peek()); // while none of the above conditions met,		
						s.pop();			 // enqueue and pop the top of the stack	
					}
				}
				catch (Exception e) { // catch exception thrown from prec method
					System.out.println("--> Error: Unknown input: " + i);
					exception = true; // set exception true to let system know there's a typo in the input
				}
				s.push(i); // when any of the above conditions met, push i onto stack
			}
		}
		while (!s.isEmpty()) { 		// when finished traversing through curLine,
			q.enqueue(s.peek());	// enqueue and pop the leftover operands in stack s
			s.pop();
		}
		
		return q; // return the queue to be evaluated
	}
	
	public static void exprNotEvaluated(Stack<Double> s) throws Exception {
		if (s.size() != 1)
			throw new Exception();
	}
	
	public static double evaluation(String line) throws Exception {
		Queue<String> q = in2post(line);
		Stack<Double> s = new Stack<>();
		double finalResult = 0;
		while(!q.isEmpty()) { 
			if(isOperand(q.peek())) {
				s.push(Double.parseDouble(q.peek())); // convert string to double and push
			} else {
				double result;
				try {
					if (numOperands(q.peek()) == 1) { 
						// if operator has right associativity
						double a = s.pop(); // only one operand
						result = operate(q.peek(), a, 0);
					} else {	
						// if operator has left to right associativity
						double a = s.pop(); // two operands
						double b = s.pop();
						result = operate(q.peek(), b, a); // switch order of b and a, because in2post reverses the order
					}
					s.push(result);
				}
				catch (Exception e) { // when the above try runs into an exception when calling numOperands or operate methods, 
									  // don't do anything, since the exception was 100% already caught previously (see the in2post method above)
				}
			}
			q.dequeue(); // move on to next element in line
		}
		
		try {
			exprNotEvaluated(s); // if the stack size is not 1, then expression wasn't fully evaluated, meaning there was an error in the inputted expression
		}
		catch (Exception e) {
			System.out.println("--> Error: Invalid expression");
			exception = true;
		}
		
		finalResult = s.peek(); // once queue is empty, set final result as the top of the stack
		
		if (exception)
			System.out.println("--> URCalculator's best guess: "); // designed the calculator so that even when there's a typo, it will ignore it and still try to calculate it
																   // this will almost always give the user their desired output
		exception = false; // reset exception to false for next call of evaluation method
		return finalResult;
	}
	
	public static void main(String[] args) throws Exception { 
		System.out.println("input file test cases");
		URLinkedList<String> expr = readFile(args);
		for (String i : expr)
			System.out.println(evaluation(i));
		
		System.out.println();
		System.out.println("additional test cases");
		
		URLinkedList<String> expr_additional = new URLinkedList<>();
		expr_additional.add(null);
		expr_additional.add("25 % 7 +25.65 * sin(5 + 7 ^ 2 * (4 % 3)) + cos(50)-tan(cos(50))"); // −10.81153
		expr_additional.add("365.4 - -(5 * !0 + 4.32 ^ 2.222)"); // 396.22527
		expr_additional.add("-tan(cos5  0)"); // -1.44356
		expr_additional.add("-tan (   -  cos(50) + 2 * 4 ^ 2.454)"); // 0.69754
		expr_additional.add("- - 1 + - 1"); // 0
		expr_additional.add("-sin2*3+12- (2+6)"); // 1.27211
		expr_additional.add(" ( 5   .  40 32 q) + ( 444.  65  20 1 * 34 ) "); // 15123.57154 despite the error
		for (String i : expr_additional) {
			System.out.println(evaluation(i));
			System.out.println();
		}
		
		
	}

}
