import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class URLinkedList<E> implements URList<E> {
	public class URIterator<E> implements Iterator<E> {
		// create curNode for hasNext() and next() to call
		URNode<E> curNode = (URNode<E>) head;
		
		@Override
		public boolean hasNext() {
			// if curNode has no next element, return false
			if(curNode.next() == null)
				return false;
			return true;
		}

		@Override
		public E next() {
			// move curNode to the next node
			curNode = curNode.next();
			return curNode.element();
		}	
	}
	
	private URNode<E> head = null;
	private URNode<E> tail = null;
	
	// Retrieves, but does not remove, the first element of this list, or returns null if
	//this list is empty.
	E peekFirst() {
		return head.element();
		
	}
	// Retrieves, but does not remove, the last element of this list, or returns null if
	// this list is empty.
	E peekLast() {
		return tail.element();
	}
	// Retrieves and removes the first element of this list, or returns null if this list
	// is empty.
	E pollFirst() {
		if(head == null)
			return null;
		else 
			return this.remove(0);
		
	}
	// Retrieves and removes the last element of this list, or returns null if this list
	// is empty.
	E pollLast() {
		if(head == null)
			return null;
		else 
			return this.remove(this.size() - 1);
		
	}
	
	public boolean equals(Object o) {
	    URLinkedList other = (URLinkedList)o; // create URLinkedList from Object o
	    URNode<E> curNode1 = head;
	    URNode<E> curNode2 = other.head;
	    while (curNode1 != null) {
	    	// check if "other" contains every element of "this"
	    	if (!other.contains(curNode1.element())) 
	    		return false; // return false when there is an element in this that other doesn't contain
	    	curNode1 = curNode1.next();
	    }
	    while (curNode2 != null) {
	    	// check if "this" contains every element of "other"
	    	if (!this.contains(curNode2.element()))
	    		return false; // return false when there is an element in "other" that "this" doesn't contain
	    	curNode2 = curNode2.next();
	    }
	    return true; // return true only if "this" contains every element of "other" AND "other" contains every element of "this"
	}

	// Prepend
	void addFirst(E e) {
		URNode<E> newNode = new URNode<E>(e, null, null);
		if (head == null) { 
			// if list is empty, set head and tail as newNode
			head = newNode;
			tail = newNode;
		} else {					
			// else, insert newNode as new head element
			newNode.setNext(head);
			head.setPrev(newNode);
			head = newNode;
			head.setPrev(null);
		}
		
	}
	// Append
	void addLast(E e) {
		URNode<E> newNode = new URNode<E>(e, null, null);
		if(head == null) {
			// if list is empty, set head and tail as newNode
			head = newNode;
			tail = newNode;
		} else {
			// else, insert newNode as new tail element
			tail.setNext(newNode);
			newNode.setPrev(tail);
			tail = newNode;
			tail.setNext(null);
		}
	}
	

	@Override
	// run addLast and return true
	public boolean add(E e) {
		this.addLast(e);
		return true;
	}

	@Override
	// insert in element at specified index
	public void add(int index, E element) {
		URNode<E> newNode = new URNode<E>(element, null, null);
		if(index == 0) 
			// if specified index is 0, just prepend
			this.addFirst(element);
		else if (index == this.size()) 
			// avoids the situation where there is one element, making curNode (head.next) null
			this.addLast(element);
		else {
			// else, traverse through linked list until reach specified index (ind = index)
			URNode<E> curNode = head.next();
			URNode<E> predNode = head; 
			int ind = 1; // traversal starts at index 1, since index 0 case was already covered.
						 // this avoids predNode = null
			while(curNode != null) {
				if(ind == index) {
					// when you reach specified index, insert newNode before curNode
					newNode.setNext(curNode);
					newNode.setPrev(predNode);
					curNode.setPrev(newNode);
					predNode.setNext(newNode);
				}
				ind++;
				predNode = predNode.next();
				curNode = curNode.next();
			}
		}
	}

	@Override
	public boolean addAll(Collection<? extends E> c) {
		for(E i : c) {
			this.addLast(i); // calls addLast for each element in c
		}
		return true;
	}

	@Override
	public boolean addAll(int index, Collection<? extends E> c) {
		int ind = index;
		for(E i : c) {
			this.add(ind, i); // calls addAtIndex for each element in c
			++ind;			  // but updates ind so that the elements end up in order
		}
		return true;
	}

	@Override
	public void clear() {
		URNode<E> curNode = head;
		while (curNode != null) {
			// continuously remove until no nodes left
			this.remove(0);
			curNode = curNode.next();
		}
			
	}

	@Override
	public boolean contains(Object o) {
		URNode<E> curNode = head; 
		while (curNode != null) {
			// traverse linked list
			if(curNode.element() == o) 
				// if element of curNode == o, return true
				return true;
			curNode = curNode.next();
		}
		return false; // returns false when no curNode with element == o found
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		for(Object i : c) 
			if(!this.contains(i)) 
				// once one element is found that is not in linked list, return false
				return false;
		return true;
	}

	@Override
	public E get(int index) {
		URNode<E> curNode = head; 
		int ind = 0;
		while(curNode != null) {
			// traverse list
			if (ind == index) 
				// when ind == index, return element of curNode
				return curNode.element();
			ind++;
			curNode = curNode.next();			
		}
		return null; // returns null when index not valid
	}

	@Override
	public int indexOf(Object o) {
		URNode<E> curNode = head; 
		int ind = 0;
		while(curNode != null) {
			// traverse list
			if (curNode.element() == o)
				// if the curNode element is == o, then return the current ind value
				return ind;
			ind++;
			curNode = curNode.next();
		}
		return -1; // returns -1 when o is not found
	}

	@Override
	public boolean isEmpty() {
		if (head == null)
			return true;
		else
			return false;
	}
	
	@Override
	public Iterator<E> iterator() {
		URIterator<E> iterator = new URIterator<>();
		return iterator;
	}

	@Override
	public E remove(int index) {
		URNode<E> curNode = head;
		URNode<E> sucNode = curNode.next();
		URNode<E> predNode = curNode.prev();
		if (index == 0) {
			// if index = 0, then remove curNode and replace sucNode as new head
			if (this.size() == 1) {
				head = null;
			} else {
				head = sucNode;
				head.setPrev(null);
			}
			return curNode.element();
		} else if(index > this.size() - 1) 
			// returns null when index is out of bounds
			return null;
		else {
			// else, traverse through linked list until reach specified index (ind = index)
			
			int ind = 1; 				// ind = 1 because index = 0 case already covered.
			curNode = curNode.next(); 	// this avoids predNode = null
			sucNode = curNode.next();
			predNode = curNode.prev();
			while(curNode != null) {
				if(ind == index) {
					// when you reach specified index, remove curNode
					if(sucNode != null) 
						sucNode.setPrev(predNode);
					if(predNode != null)
						predNode.setNext(sucNode);
					if(curNode == tail) {
						tail = predNode;
						tail.setNext(null);
					}
					return curNode.element();
				}
				ind++;
				curNode = curNode.next();
				sucNode = sucNode.next();
				predNode = predNode.next();
			}
			return null;
		}
	}
	
	@Override
	public boolean remove(Object o) {
		if (head.element() == o) {
			// takes care of the case when o is the head
			head = head.next();
			if(this.size() == 1)
				head.setPrev(null);
			return true;
		} else {
			// if o is not the head, then traverse through list, starting from the element after head
			// this avoids predNode == null
			URNode<E> curNode = head.next();
			URNode<E> sucNode = curNode.next();
			URNode<E> predNode = curNode.prev();
			while(curNode != null) {
				if(curNode.element() == o) {
					if(sucNode != null)
						// if curNode is not tail
						sucNode.setPrev(predNode);
					if(predNode != null)
						// if curNode is not head
						predNode.setNext(sucNode);
					if(curNode == tail)
						// if curNode is tail
						tail = predNode;
						tail.setNext(null);
					return true;
				}
				
				if(curNode != tail) { // avoids sucNode == null error in the case when curNode is tail AND o is not found 
									  // (i.e. when o is not an element of linked list
				sucNode = sucNode.next();
				predNode = predNode.next();
				}
				
				curNode = curNode.next(); // outside of above if statement because regardless of what happens, curNode must
										  // advance to reach the while case
			}
		}
		return false; // returns false when o not found
	}
		
	@Override
	public boolean removeAll(Collection<?> c) {
		for(Object i : c) {
			remove(i);
		}
		return true; // return true when removeAll executed 
	}

	@Override
	public E set(int index, E element) {
		int ind = 0;
		URNode<E> curNode = head;
		while(curNode != null) {
			if(ind == index) {
				// just set element, as next or prev don't need to change
				curNode.setElement(element);
				return element; // return new element when set executes 
			}
			curNode = curNode.next();
			ind++;
		}
		return null; // return null if index not found
	}

	@Override
	public int size() {
		URNode<E> curNode = head;
		int size = 0;
		while(curNode != null) {
			size += 1;
			curNode = curNode.next();		
		}
		
		return size; // return final size
	}

	@Override
	public URList<E> subList(int fromIndex, int toIndex) {
		if(fromIndex < 0 || toIndex > this.size() || fromIndex > toIndex)
			// if indexes out of bounds or toIndex less than fromIndex, return null
			return null;
		
		URLinkedList<E> sub = new URLinkedList<>(); // create sublist
		int ind = 0;
		URNode<E> curNode = head;
		while(curNode != null) {
			if(ind >= fromIndex && ind < toIndex)  // for each element of linked list, add elements of specified indexes to sublist
				sub.add(curNode.element());	
			curNode = curNode.next();
			ind++;			
		}
		return sub; // return sublist
	}

	@Override
	public Object[] toArray() {
		Object[] array = new Object[this.size()];
		URNode curNode = head;
		int ind = 0;
		while(curNode != null) {
			// add each element of linked list to array
			array[ind] = curNode.element();
			curNode = curNode.next();
			ind++;
		}
		return array; // return the final array
	}
	
	public String toString() {
		// for unit testing
        String result = "";
        URNode curNode = head;
        while(curNode != null) {
            result += curNode.element();
            if(curNode.next() != null){
                 result += ", ";
            }
            curNode = curNode.next();
        }
        return result;
}

}