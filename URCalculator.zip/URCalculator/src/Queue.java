
public class Queue<E> extends URLinkedList<E> {
	
	public boolean enqueue(E e) {
		return this.add(e);
	}
	
	public E element() {
		return this.get(0);
	}
	
	public boolean offer(E e) {
		return this.add(e);
	}
	
	public E peek() {
		return this.peekFirst();
	}
	
	public E poll() {
		return this.pollFirst();
	}
	
	public E dequeue() {
		return this.remove(0);
	}
}
