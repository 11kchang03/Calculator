import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

public class GUI extends JFrame implements ActionListener {
	String str = "";
	String prev_input = "";
	String prev, curr;
	static JButton add, sub, div, mul, clear, del, equ, dec, neg, mod, 
	sin, cos, tan, openPar, closePar, exp, not, and, or, less, great, enter;
	static JTextField output;
	static JButton[] num = new JButton[10];
	final JButton[] ops = {add, sub, div, mul, equ, dec, neg, mod, 
			sin, cos, tan, openPar, closePar, exp, not, and, or, less, great};
	boolean calculated = false;
	
	public void delete() {
		str = str.substring(0, str.length() - 1);
		prev_input = str.substring(str.length() - 1);
	}

	public void clear() {
		str = "";
	}

	public void updateOutput() {
		output.setText(str);
		output.repaint();
	}

	public void appendToOutput(JButton btn) {
		if (calculated) {
			str = "";
			calculated = false;
		}
		if (btn == neg) {
			str = str + "-";
			prev_input = "-";
		} else if (btn == not) {
			str = str + "!";
			prev_input = "!";
		} else if (URCalculator.isOperator(btn.getText().replaceAll("\\s+", ""))) { 
			if (URCalculator.isOperand(prev_input) || prev_input.equals(")")) {
				str = str + btn.getText().replaceAll("\\s+", "");
				prev_input = btn.getText().replaceAll("\\s+", "");
			}
		} else {
			str = str + btn.getText().replaceAll("\\s+", "");
			prev_input = btn.getText().replaceAll("\\s+", "");
		}
	}

	public void calculate() throws Exception {
		str = String.valueOf(URCalculator.evaluation(str));
		calculated = true;
	}
	
	public GUI() {
		super("URCalculator");
		
		// sub panels and set layouts
		JPanel row1 = new JPanel();
		row1.setLayout(new BoxLayout(row1, BoxLayout.LINE_AXIS));
		
		JPanel row2 = new JPanel();
		row2.setLayout(new BoxLayout(row2, BoxLayout.LINE_AXIS));
		
		JPanel row3 = new JPanel();
		row3.setLayout(new BoxLayout(row3, BoxLayout.LINE_AXIS));
		
		JPanel row4 = new JPanel();
		row4.setLayout(new BoxLayout(row4, BoxLayout.LINE_AXIS));
		
		JPanel row5 = new JPanel();
		row5.setLayout(new BoxLayout(row5, BoxLayout.LINE_AXIS));
		
		JPanel row6 = new JPanel();
		row6.setLayout(new BoxLayout(row6, BoxLayout.LINE_AXIS));
		
		JPanel row7 = new JPanel();
		row7.setLayout(new BoxLayout(row7, BoxLayout.LINE_AXIS));
		
		
		// initialize buttons and set fonts
		output = new JTextField(16);
		
		
		del = new JButton(" del ");
		del.setFont(new Font("Monospaced", Font.BOLD, 22));
		
		clear = new JButton("clear");
		clear.setFont(new Font("Monospaced", Font.BOLD, 22));
		
		openPar = new JButton(" ( ");
		openPar.setFont(new Font("Monospaced", Font.BOLD, 22));
		
		closePar = new JButton(" ) ");
		closePar.setFont(new Font("Monospaced", Font.BOLD, 22));
		
		sin = new JButton("sin");
		sin.setFont(new Font("Monospaced", Font.BOLD, 22));
		
		cos = new JButton("cos");
		cos.setFont(new Font("Monospaced", Font.BOLD, 22));
		
		tan = new JButton("tan");
		tan.setFont(new Font("Monospaced", Font.BOLD, 22));
		
		great = new JButton(" > ");
		great.setFont(new Font("Monospaced", Font.BOLD, 22));
		
		less = new JButton(" < ");
		less.setFont(new Font("Monospaced", Font.BOLD, 22));
		
		mod = new JButton(" % ");
		mod.setFont(new Font("Monospaced", Font.BOLD, 22));
		
		exp = new JButton(" ^ ");
		exp.setFont(new Font("Monospaced", Font.BOLD, 22));
		
		div = new JButton(" / ");
		div.setFont(new Font("Monospaced", Font.BOLD, 22));

		equ = new JButton(" = ");
		equ.setFont(new Font("Monospaced", Font.BOLD, 22));
		
		mul = new JButton(" * ");
		mul.setFont(new Font("Monospaced", Font.BOLD, 22));

		not = new JButton(" ! ");
		not.setFont(new Font("Monospaced", Font.BOLD, 22));
		
		sub = new JButton(" - ");
		sub.setFont(new Font("Monospaced", Font.BOLD, 22));

		and = new JButton(" & ");
		and.setFont(new Font("Monospaced", Font.BOLD, 22));
		
		add = new JButton(" + ");
		add.setFont(new Font("Monospaced", Font.BOLD, 22));

		or = new JButton(" | ");
		or.setFont(new Font("Monospaced", Font.BOLD, 22));

		dec = new JButton(" . ");
		dec.setFont(new Font("Monospaced", Font.BOLD, 22));
		
		neg = new JButton("(-)");
		neg.setFont(new Font("Monospaced", Font.BOLD, 22));
		
		enter = new JButton("ENT");
		enter.setFont(new Font("Monospaced", Font.BOLD, 22));
		
		// used iteration to avoid redundancy
		for (int count = 0; count < num.length ; count++) {
			num[count] = new JButton(" " + String.valueOf(count) + " ");
			num[count].setFont(new Font("Monospaced", Font.BOLD, 22));
		}
		
		
		// set the display of the output
		output.setMaximumSize(new Dimension (300, 40));
		output.setFont(new Font("Monospaced", Font.BOLD, 27));
		output.setDisabledTextColor(new Color(0, 0, 0));
		output.setMargin(new Insets(0, 5, 0, 0));
		output.setText("0");


		// add buttons to each row
		// row 1
		row1.add(del);
		row1.add(clear);
		// row 2
		row2.add(openPar);
		row2.add(closePar);
		row2.add(sin);
		row2.add(cos);
		row2.add(tan);
		// row 3
		row3.add(great);
		row3.add(less);
		row3.add(mod);
		row3.add(exp);
		row3.add(div);
		// row 4
		row4.add(equ);
		row4.add(num[7]);
		row4.add(num[8]);
		row4.add(num[9]);
		row4.add(mul);
		// row 5
		row5.add(not);
		row5.add(num[4]);
		row5.add(num[5]);
		row5.add(num[6]);
		row5.add(sub);
		// row 6
		row6.add(and);
		row6.add(num[1]);
		row6.add(num[2]);
		row6.add(num[3]);
		row6.add(add);
		// row 7
		row7.add(or);
		row7.add(num[0]);
		row7.add(dec);
		row7.add(neg);
		row7.add(enter);
		

		
		JPanel main = new JPanel();
		main.setLayout(new BoxLayout(main, BoxLayout.PAGE_AXIS));
		main.add(output);
		main.add(Box.createRigidArea(new Dimension(0, 5)));
		main.add(row1);
		main.add(row2);
		main.add(row3);
		main.add(row4);
		main.add(row5);
		main.add(row6);
		main.add(row7);
		
		this.add(main);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setSize(381, 370);
		
		del.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				delete();
				updateOutput();
			}
		});
		
		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clear();
				updateOutput();
			}
		}); 
		
		enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					calculate();
				} catch (Exception e1) {
					str = "ERROR";
				} finally {updateOutput();}
			}
		});

		final JButton[] opsNum = {add, sub, div, mul, equ, dec, neg, mod, 
				sin, cos, tan, openPar, closePar, exp, not, and, or, less, great, num[0], num[1], num[2],
				num[3], num[4], num[5], num[6], num[7], num[8], num[9]};
		
		for (JButton f : opsNum) {
			f.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					appendToOutput(f);
					updateOutput();
				}
			});
		}	
	}



public static void main(String arg[]) {
	new GUI();
}

@Override
public void actionPerformed(ActionEvent e) {
	
}


}
