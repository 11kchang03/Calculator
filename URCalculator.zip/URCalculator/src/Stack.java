
public class Stack<E> extends URLinkedList<E> {
	
	public boolean empty() {
		return this.isEmpty();
	}
	
	public E peek() {
		return this.peekLast();
	}
	
	public E pop() {
		return this.remove(this.size() - 1);
	}
	
	public void push(E e) {
		this.addLast(e);
	}
	
	public int search(Object o) {
		return this.indexOf(o);
	}

}
